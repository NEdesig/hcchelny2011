# Челны 2011 — сайт и админка
1. `npm install`
2. Положите шрифты: public/fonts/stapel.ttf и public/fonts/stengazeta.ttf
3. Запуск: `ADMIN_PASSWORD=ваш_пароль ADMIN_PATH=/секретный-адрес npm start`
4. Сайт: http://localhost:3000   Админка: http://localhost:3000/секретный-адрес (на сайте ссылок на неё нет)
Сначала добавьте клубы, затем матчи. Данные: data/db.json, фото: uploads/.
